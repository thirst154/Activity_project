<template>
    <div>
      <h1>Profile Page</h1>
      
    </div>
  </template>
  
  <script>
  export default {
    
  };
  </script>
  
  <style scoped>
  
  </style>