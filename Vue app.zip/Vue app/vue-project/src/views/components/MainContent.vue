<template>
    
  </template>
  
  <script>
  
  </script>
  
  <style scoped>
  .main-content {
    flex: 2;
    padding: 15px;
  }
  
  .post-list {
    list-style-type: none;
    padding: 0;
  }
  
  .post-list li {
    margin-bottom: 10px;
    cursor: pointer;
  }
  </style>